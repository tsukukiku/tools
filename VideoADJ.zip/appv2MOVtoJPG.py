import cv2
import numpy as np
import os
import zipfile
import tempfile
from datetime import datetime
import gradio as gr

# ================= 核心图像与矩阵算法逻辑 =================

def order_points(pts):
    """将输入的 4 个点按 [左上, 右上, 右下, 左下] 顺时针排序"""
    pts = np.array(pts, dtype="float32")
    rect = np.zeros((4, 2), dtype="float32")
    s = pts.sum(axis=1)
    rect[0] = pts[np.argmin(s)]  # 左上角 (Top-Left)
    rect[2] = pts[np.argmax(s)]  # 右下角 (Bottom-Right)

    diff = np.diff(pts, axis=1)
    rect[1] = pts[np.argmin(diff)]  # 右上角 (Top-Right)
    rect[3] = pts[np.argmax(diff)]  # 左下角 (Bottom-Left)
    return rect

def detect_ppt_quad(img):
    """检测图像中的 PPT 屏幕 4 角顶点与完整度占比"""
    h, w = img.shape[:2]
    img_area = h * w

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    
    edges = cv2.Canny(blurred, 50, 200)
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (7, 7))
    closed = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, kernel)

    cnts, _ = cv2.findContours(closed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not cnts:
        return None, 0.0

    cnts = sorted(cnts, key=cv2.contourArea, reverse=True)

    for c in cnts[:5]:
        area = cv2.contourArea(c)
        area_ratio = area / img_area
        
        if area_ratio < 0.10:
            continue

        peri = cv2.arcLength(c, True)
        approx = cv2.approxPolyDP(c, 0.025 * peri, True)

        if len(approx) == 4 and cv2.isContourConvex(approx):
            pts = approx.reshape(4, 2)
            return order_points(pts), area_ratio

    return None, 0.0

def calculate_homography_and_size(img_shape, src_pts):
    """计算全局透视变换矩阵，保证拉伸校正后画面完整不被裁切"""
    h, w = img_shape[:2]
    tl, tr, br, bl = src_pts

    width_top = np.linalg.norm(tr - tl)
    width_bottom = np.linalg.norm(br - bl)
    target_w = max(int(width_top), int(width_bottom))

    height_left = np.linalg.norm(bl - tl)
    height_right = np.linalg.norm(br - tr)
    target_h = max(int(height_left), int(height_right))

    dst_pts = np.float32([
        [0, 0],
        [target_w, 0],
        [target_w, target_h],
        [0, target_h]
    ])

    H = cv2.getPerspectiveTransform(src_pts, dst_pts)

    img_corners = np.float32([[0, 0], [w, 0], [w, h], [0, h]]).reshape(-1, 1, 2)
    transformed_corners = cv2.perspectiveTransform(img_corners, H)

    x_coords = transformed_corners[:, 0, 0]
    y_coords = transformed_corners[:, 0, 1]

    x_min, x_max = np.min(x_coords), np.max(x_coords)
    y_min, y_max = np.min(y_coords), np.max(y_coords)

    new_w = int(np.ceil(x_max - x_min))
    new_h = int(np.ceil(y_max - y_min))

    T = np.array([
        [1, 0, -x_min],
        [0, 1, -y_min],
        [0, 0, 1]
    ], dtype=np.float32)

    H_final = T @ H
    return H_final, (new_w, new_h)

def warp_image_by_pts(img_bgr, pts):
    """通过指定的 4 点进行全图透视校正拉伸"""
    ordered_pts = order_points(pts)
    H_final, new_size = calculate_homography_and_size(img_bgr.shape, ordered_pts)
    rectified_bgr = cv2.warpPerspective(
        img_bgr, H_final, new_size,
        flags=cv2.INTER_CUBIC,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=(255, 255, 255)
    )
    return rectified_bgr

def draw_sequential_points(img_bgr, pts):
    """在图像上按 1,2,3,4 顺序绘制红色标定点、绿色序号与蓝色连线"""
    img_drawn = img_bgr.copy()
    if len(pts) > 0:
        for i, p in enumerate(pts):
            cv2.circle(img_drawn, (int(p[0]), int(p[1])), 8, (0, 0, 255), -1)  # 红点
            cv2.putText(img_drawn, str(i + 1), (int(p[0]) + 12, int(p[1]) + 12),
                        cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 255, 0), 2)  # 绿字 1,2,3,4
        if len(pts) > 1:
            pts_arr = np.array(pts, dtype=np.int32)
            cv2.polylines(img_drawn, [pts_arr], isClosed=(len(pts) == 4), color=(255, 0, 0), thickness=2)
    return img_drawn

# ================= 视频分析与帧提取 =================

def calculate_sharpness(frame):
    """计算帧清晰度（拉普拉斯方差）"""
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    return cv2.Laplacian(gray, cv2.CV_64F).var()

def find_best_ppt_frame(video_path, sample_step=5):
    """综合评估【清晰度】+【PPT 屏幕未被遮挡完整度】挑选最佳帧"""
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        return 0, 0, 0, None

    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    if total_frames <= 0:
        cap.release()
        return 0, 0, 0, None

    best_frame_idx = 0
    max_score = -1.0
    best_pts = None

    for idx in range(0, total_frames, sample_step):
        cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
        ret, frame = cap.read()
        if not ret or frame is None:
            continue

        sharpness = calculate_sharpness(frame)
        pts, area_ratio = detect_ppt_quad(frame)

        occlusion_penalty = 1.0 if pts is not None else 0.15
        composite_score = sharpness * (1.0 + area_ratio * 2.0) * occlusion_penalty

        if composite_score > max_score:
            max_score = composite_score
            best_frame_idx = idx
            best_pts = pts

    cap.release()
    return best_frame_idx, round(max_score, 2), total_frames, best_pts

def extract_frame_at_index(video_path, frame_idx):
    """提取指定帧"""
    cap = cv2.VideoCapture(video_path)
    cap.set(cv2.CAP_PROP_POS_FRAMES, frame_idx)
    ret, frame_bgr = cap.read()
    cap.release()
    if ret and frame_bgr is not None:
        return frame_bgr
    return None

# ================= Web 交互函数 =================

def render_display_tuple(item, enable_keystone):
    """根据当前视频的状态（自动点/手动点）生成双通道 UI 预览视图"""
    img_bgr = item["bgr"]
    if img_bgr is None:
        return None, None

    manual_pts = item.get("manual_pts", [])
    auto_pts = item.get("auto_pts", None)
    scale = item.get("scale", 1.0)

    disp_img = cv2.resize(img_bgr, (int(img_bgr.shape[1] * scale), int(img_bgr.shape[0] * scale)))

    # 1. 绘制左侧原图标定预览图
    if len(manual_pts) > 0:
        disp_pts = [[int(p[0] * scale), int(p[1] * scale)] for p in manual_pts]
        annotated_bgr = draw_sequential_points(disp_img, disp_pts)
    elif auto_pts is not None:
        annotated_bgr = disp_img.copy()
        auto_pts_disp = (auto_pts * scale).astype(int)
        cv2.polylines(annotated_bgr, [auto_pts_disp], isClosed=True, color=(0, 255, 0), thickness=2)
        for p in auto_pts_disp:
            cv2.circle(annotated_bgr, tuple(p), 6, (255, 0, 0), -1)
    else:
        annotated_bgr = disp_img.copy()

    # 2. 生成右侧校正导出预览图
    active_pts = manual_pts if len(manual_pts) == 4 else (auto_pts if auto_pts is not None else None)
    if enable_keystone and active_pts is not None:
        rectified_bgr = warp_image_by_pts(img_bgr, active_pts)
    else:
        rectified_bgr = img_bgr

    annotated_rgb = cv2.cvtColor(annotated_bgr, cv2.COLOR_BGR2RGB)
    rectified_rgb = cv2.cvtColor(rectified_bgr, cv2.COLOR_BGR2RGB)
    return annotated_rgb, rectified_rgb

def analyze_uploaded_videos(files, enable_keystone, state):
    """批量解析视频并初始化 UI 缩放数据"""
    if not files:
        return state, gr.Dropdown(choices=[]), gr.Slider(), None, None, "⚠️ 请先上传视频文件！", ""

    state = {}
    video_names = []

    for file in files:
        file_path = file.name
        filename = os.path.basename(file_path)
        video_names.append(filename)

        best_idx, score, total_frames, auto_pts = find_best_ppt_frame(file_path)
        img_bgr = extract_frame_at_index(file_path, best_idx)

        h, w = img_bgr.shape[:2] if img_bgr is not None else (100, 100)
        scale = min(1.0, 1024.0 / max(h, w))

        state[filename] = {
            "path": file_path,
            "total_frames": total_frames,
            "chosen_frame": best_idx,
            "auto_pts": auto_pts,
            "manual_pts": [],
            "score": score,
            "bgr": img_bgr,
            "scale": scale
        }

    first_video = video_names[0]
    info = state[first_video]
    annotated_rgb, rectified_rgb = render_display_tuple(info, enable_keystone)

    status_msg = f"✅ 已完成 {len(files)} 个视频分析！算法已定位最佳帧与 PPT 边界。"
    info_text = f"📹 当前视频: {first_video} | 全视频共 {info['total_frames']} 帧\n自动选出第 {info['chosen_frame']} 帧 (质量得分: {info['score']}) | 手动标注