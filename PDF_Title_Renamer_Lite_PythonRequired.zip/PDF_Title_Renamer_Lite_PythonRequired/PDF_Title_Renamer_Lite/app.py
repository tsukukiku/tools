from __future__ import annotations

import base64
import ctypes
import io
import json
import os
import re
import subprocess
import sys
import tempfile
import urllib.parse
import webbrowser
import zipfile
from dataclasses import asdict, dataclass
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any


def add_bundled_python_packages() -> None:
    bundled_site_packages = (
        Path.home()
        / ".cache"
        / "codex-runtimes"
        / "codex-primary-runtime"
        / "dependencies"
        / "python"
        / "Lib"
        / "site-packages"
    )
    if bundled_site_packages.exists():
        sys.path.insert(0, str(bundled_site_packages))


add_bundled_python_packages()


def app_base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent

try:
    import pdfplumber
except Exception as exc:  # pragma: no cover - shown in browser at runtime
    pdfplumber = None
    PDFPLUMBER_ERROR = exc
else:
    PDFPLUMBER_ERROR = None

try:
    from pypdf import PdfReader
except Exception as exc:  # pragma: no cover - shown in browser at runtime
    PdfReader = None
    PYPDF_ERROR = exc
else:
    PYPDF_ERROR = None


PORT = int(os.environ.get("PDF_RENAMER_PORT", "8765"))
MAX_PDFS_PER_SCAN = 10
YEAR_RE = re.compile(r"\b(19[5-9]\d|20[0-4]\d|2050)\b")
YEAR_IN_TEXT_RE = re.compile(r"(19[5-9]\d|20[0-4]\d|2050)")
PDF_DATE_RE = re.compile(r"D:(\d{4})")
PROTECTED_SCAN_EXTENSIONS = {
    ".pdf",
    ".csv",
    ".doc",
    ".docx",
    ".docm",
    ".xls",
    ".xlsx",
    ".xlsm",
    ".ppt",
    ".pptx",
    ".pptm",
}
OOXML_EXTENSIONS = {".docx", ".docm", ".xlsx", ".xlsm", ".pptx", ".pptm"}
OLE_EXTENSIONS = {".doc", ".xls", ".ppt"}
MIP_MARKERS = (
    b"MSIP_Label",
    b"Microsoft Information Protection",
    b"Azure Rights Management",
    "MSIP_Label".encode("utf-16le"),
    "Microsoft Information Protection".encode("utf-16le"),
    "Azure Rights Management".encode("utf-16le"),
)
OFFICE_ENCRYPTION_MARKERS = (
    b"EncryptedPackage",
    b"EncryptionInfo",
    "EncryptedPackage".encode("utf-16le"),
    "EncryptionInfo".encode("utf-16le"),
)
BAD_TITLE_WORDS = {
    "abstract",
    "keywords",
    "references",
    "contents",
    "introduction",
    "copyright",
    "all rights reserved",
    "doi",
    "http",
    "www.",
    "arxiv",
    "journal",
    "vol.",
    "volume",
    "issue",
    "page",
    "pages",
}
GENERIC_METADATA_TITLES = {
    "untitled",
    "microsoft word",
    "document",
    "article",
    "full text",
    "manuscript",
}


@dataclass
class PreviewLine:
    text: str
    size: float
    bold: bool
    top: float


@dataclass
class PdfSuggestion:
    path: str
    currentName: str
    isEncrypted: bool
    needsPassword: bool
    encryptionStatus: str
    titleCandidates: list[str]
    yearCandidates: list[str]
    metadataTitle: str
    metadataYears: list[str]
    firstPagePreview: str
    firstPageImage: str
    previewLines: list[PreviewLine]
    totalPdfCount: int
    loadedPdfCount: int
    error: str | None = None


def normalize_space(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").strip()


def clean_line(line: str) -> str:
    line = normalize_space(line)
    return line.strip(" \t\r\n-_|•·")


def unique_keep_order(values: list[str]) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for value in values:
        value = clean_line(value)
        key = value.casefold()
        if value and key not in seen:
            seen.add(key)
            out.append(value)
    return out


def metadata_to_text(value: Any) -> str:
    if value is None:
        return ""
    return normalize_space(str(value))


def collect_metadata_years(metadata: Any) -> list[str]:
    years: list[str] = []
    if not metadata:
        return years
    for key in ("/CreationDate", "/ModDate"):
        value = metadata_to_text(metadata.get(key))
        match = PDF_DATE_RE.search(value)
        if match:
            years.append(match.group(1))
    for value in metadata.values():
        years.extend(YEAR_RE.findall(metadata_to_text(value)))
    return unique_keep_order(years)


def inspect_pdf_security(path: Path) -> tuple[bool, bool, str]:
    if PdfReader is None:
        return False, False, "无法检测加密状态：缺少 pypdf"
    try:
        reader = PdfReader(str(path))
        metadata = reader.metadata or {}
        metadata_text = " ".join(f"{key} {value}" for key, value in metadata.items()).casefold()
        if "msip_label" in metadata_text or "microsoft information protection" in metadata_text:
            return True, True, "Microsoft Information Protection / Azure Rights Management 保护"
        if not reader.is_encrypted:
            return False, False, ""
        try:
            decrypt_result = reader.decrypt("")
        except Exception:
            decrypt_result = 0
        if decrypt_result:
            return True, False, "已加密，但可用空密码读取"
        return True, True, "需要密码或受保护，无法自动读取"
    except Exception as exc:
        message = str(exc)
        encrypted_hint = any(word in message.casefold() for word in ("encrypted", "decrypt", "password"))
        if encrypted_hint:
            return True, True, f"可能需要密码：{message}"
        return False, False, ""


def read_binary_sample(path: Path, limit: int = 2_000_000) -> bytes:
    try:
        with path.open("rb") as handle:
            return handle.read(limit)
    except Exception:
        return b""


def has_marker(data: bytes, markers: tuple[bytes, ...]) -> bool:
    return any(marker in data for marker in markers)


def inspect_ooxml_or_ole_security(path: Path) -> tuple[bool, str]:
    suffix = path.suffix.casefold()
    sample = read_binary_sample(path)
    if has_marker(sample, MIP_MARKERS):
        return True, "Microsoft Information Protection / Azure Rights Management 保护"
    if has_marker(sample, OFFICE_ENCRYPTION_MARKERS):
        return True, "Office 密码保护或加密容器"

    if suffix in OOXML_EXTENSIONS:
        try:
            with zipfile.ZipFile(path) as archive:
                for name in archive.namelist():
                    lower_name = name.casefold()
                    if lower_name.startswith("docprops/") or lower_name.endswith(".xml"):
                        try:
                            content = archive.read(name, pwd=None)
                        except Exception:
                            continue
                        if has_marker(content[:2_000_000], MIP_MARKERS):
                            return True, "Microsoft Information Protection / Azure Rights Management 保护"
                return False, ""
        except zipfile.BadZipFile:
            if sample.startswith(b"\xd0\xcf\x11\xe0"):
                return True, "Office 密码保护或加密容器"
            return False, ""
        except RuntimeError as exc:
            if "password" in str(exc).casefold():
                return True, "Office 密码保护"
            return False, ""
        except Exception:
            return False, ""

    if suffix in OLE_EXTENSIONS and sample.startswith(b"\xd0\xcf\x11\xe0"):
        if has_marker(sample, OFFICE_ENCRYPTION_MARKERS):
            return True, "Office 密码保护或加密容器"
        if has_marker(sample, MIP_MARKERS):
            return True, "Microsoft Information Protection / Azure Rights Management 保护"
    return False, ""


def inspect_csv_security(path: Path) -> tuple[bool, str]:
    sample = read_binary_sample(path)
    if has_marker(sample, MIP_MARKERS):
        return True, "Microsoft Information Protection / Azure Rights Management 保护"
    return False, ""


def inspect_protected_file(path: Path) -> dict[str, Any] | None:
    suffix = path.suffix.casefold()
    try:
        size = path.stat().st_size
    except OSError:
        size = 0

    if suffix == ".pdf":
        is_encrypted, needs_password, status = inspect_pdf_security(path)
        if is_encrypted:
            return {
                "path": str(path),
                "name": path.name,
                "type": "PDF",
                "status": status or "PDF 加密/受保护",
                "needsPassword": needs_password,
                "size": size,
            }
        return None

    if suffix in OOXML_EXTENSIONS or suffix in OLE_EXTENSIONS:
        protected, status = inspect_ooxml_or_ole_security(path)
        if protected:
            return {
                "path": str(path),
                "name": path.name,
                "type": suffix.lstrip(".").upper(),
                "status": status,
                "needsPassword": "密码" in status or "加密容器" in status or "Rights Management" in status,
                "size": size,
            }
        return None

    if suffix == ".csv":
        protected, status = inspect_csv_security(path)
        if protected:
            return {
                "path": str(path),
                "name": path.name,
                "type": "CSV",
                "status": status,
                "needsPassword": True,
                "size": size,
            }
    return None


def scan_protected_files_recursive(folder: Path) -> tuple[list[dict[str, Any]], int]:
    scanned = 0
    results: list[dict[str, Any]] = []
    for path in sorted(folder.rglob("*"), key=lambda p: str(p).casefold()):
        if not path.is_file():
            continue
        if path.suffix.casefold() not in PROTECTED_SCAN_EXTENSIONS:
            continue
        scanned += 1
        result = inspect_protected_file(path)
        if result:
            results.append(result)
    return results, scanned


def write_protected_report(folder: Path, results: list[dict[str, Any]], scanned: int) -> Path:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_path = folder / f"protected_files_report_{timestamp}.txt"
    lines = [
        "Protected files report",
        f"Scan folder: {folder}",
        f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"Scanned files: {scanned}",
        f"Protected files: {len(results)}",
        "",
    ]
    if not results:
        lines.append("No password-protected or Microsoft Information Protection files found.")
    else:
        for index, item in enumerate(results, 1):
            lines.extend(
                [
                    f"{index}. {item['name']}",
                    f"   Type: {item['type']}",
                    f"   Status: {item['status']}",
                    f"   Path: {item['path']}",
                    f"   Size: {item['size']} bytes",
                    "",
                ]
            )
    report_path.write_text("\n".join(lines), encoding="utf-8")
    return report_path


def is_probable_title(line: str) -> bool:
    line = clean_line(line)
    lower = line.casefold()
    if len(line) < 8 or len(line) > 190:
        return False
    if any(word in lower for word in BAD_TITLE_WORDS):
        return False
    if re.search(r"[@]|https?://|www\.", lower):
        return False
    letters = re.findall(r"[A-Za-z]", line)
    if len(letters) < 5:
        return False
    if len(re.findall(r"\d", line)) > max(6, len(line) // 4):
        return False
    if line.count(",") >= 3 and len(line.split()) <= 18:
        return False
    if re.fullmatch(r"[\W\d_]+", line):
        return False
    if lower in GENERIC_METADATA_TITLES:
        return False
    return True


def text_from_pypdf(path: Path) -> tuple[str, str, list[str], str | None]:
    if PdfReader is None:
        if pdfplumber is None:
            return "", "", [], f"Missing pypdf and pdfplumber: {PYPDF_ERROR}; {PDFPLUMBER_ERROR}"
        try:
            with pdfplumber.open(str(path)) as pdf:
                first_page_text = pdf.pages[0].extract_text() if pdf.pages else ""
                metadata = pdf.metadata or {}
                metadata_title = metadata_to_text(metadata.get("Title") or metadata.get("/Title"))
                return first_page_text or "", metadata_title, collect_metadata_years(metadata), None
        except Exception as exc:
            return "", "", [], str(exc)
    try:
        reader = PdfReader(str(path))
        metadata = reader.metadata or {}
        first_page_text = reader.pages[0].extract_text() if reader.pages else ""
        metadata_title = metadata_to_text(metadata.get("/Title"))
        return first_page_text or "", metadata_title, collect_metadata_years(metadata), None
    except Exception as exc:
        return "", "", [], str(exc)


def line_key(word: dict[str, Any]) -> int:
    return int(round(float(word.get("top", 0)) / 4))


def extract_layout_lines(path: Path) -> tuple[list[PreviewLine], str | None]:
    if pdfplumber is None:
        return [], f"缺少 pdfplumber：{PDFPLUMBER_ERROR}"
    try:
        with pdfplumber.open(str(path)) as pdf:
            if not pdf.pages:
                return [], None
            page = pdf.pages[0]
            words = page.extract_words(extra_attrs=["size", "fontname"], keep_blank_chars=False)
            grouped: dict[int, list[dict[str, Any]]] = {}
            for word in words:
                top = float(word.get("top", 0))
                if top > float(page.height) * 0.55:
                    continue
                grouped.setdefault(line_key(word), []).append(word)

            lines: list[PreviewLine] = []
            for parts in grouped.values():
                parts.sort(key=lambda item: float(item.get("x0", 0)))
                text = clean_line(" ".join(str(item.get("text", "")) for item in parts))
                if not text:
                    continue
                sizes = [float(item.get("size", 0)) for item in parts if item.get("size")]
                fonts = " ".join(str(item.get("fontname", "")) for item in parts).casefold()
                lines.append(
                    PreviewLine(
                        text=text,
                        size=round(sum(sizes) / len(sizes), 1) if sizes else 10.0,
                        bold=("bold" in fonts or "black" in fonts or "heavy" in fonts),
                        top=round(min(float(item.get("top", 0)) for item in parts), 1),
                    )
                )
            lines.sort(key=lambda item: item.top)
            return lines[:80], None
    except Exception as exc:
        return [], str(exc)


def render_first_page_image(path: Path) -> str:
    base_dir = app_base_dir()
    portable_candidates = [
        base_dir / "poppler" / "Library" / "bin" / "pdftoppm.exe",
        base_dir / "poppler" / "bin" / "pdftoppm.exe",
    ]
    codex_pdftoppm_exe = (
        Path.home()
        / ".cache"
        / "codex-runtimes"
        / "codex-primary-runtime"
        / "dependencies"
        / "native"
        / "poppler"
        / "Library"
        / "bin"
        / "pdftoppm.exe"
    )
    codex_pdftoppm_cmd = (
        Path.home()
        / ".cache"
        / "codex-runtimes"
        / "codex-primary-runtime"
        / "dependencies"
        / "bin"
        / "pdftoppm.cmd"
    )
    candidates = portable_candidates + [codex_pdftoppm_exe, codex_pdftoppm_cmd]
    pdftoppm = next((candidate for candidate in candidates if candidate.exists()), Path(""))
    if pdftoppm.exists():
        try:
            with tempfile.TemporaryDirectory(prefix="pdf_renamer_preview_") as tmpdir:
                output_prefix = Path(tmpdir) / "page"
                command = [
                    str(pdftoppm),
                    "-f",
                    "1",
                    "-l",
                    "1",
                    "-png",
                    "-r",
                    "95",
                    str(path),
                    str(output_prefix),
                ]
                completed = subprocess.run(
                    command,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    timeout=20,
                    check=False,
                )
                if completed.returncode == 0:
                    png_files = sorted(Path(tmpdir).glob("page-*.png"))
                    if png_files:
                        data = png_files[0].read_bytes()
                        return "data:image/png;base64," + base64.b64encode(data).decode("ascii")
        except Exception:
            pass

    try:
        import pypdfium2 as pdfium

        document = pdfium.PdfDocument(str(path))
        if len(document) < 1:
            return ""
        page = document[0]
        bitmap = page.render(scale=95 / 72).to_pil()
        buffer = io.BytesIO()
        bitmap.save(buffer, format="PNG")
        return "data:image/png;base64," + base64.b64encode(buffer.getvalue()).decode("ascii")
    except Exception:
        return ""


def title_score(line: PreviewLine | str, index: int, before_abstract: bool, max_size: float) -> tuple[int, int]:
    if isinstance(line, PreviewLine):
        text = line.text
        size = line.size
        bold = line.bold
    else:
        text = line
        size = 0
        bold = False

    words = text.split()
    score = 0
    if before_abstract:
        score += 25
    if 5 <= len(words) <= 18:
        score += 25
    elif 3 <= len(words) <= 24:
        score += 12
    if max_size and size >= max_size - 0.5:
        score += 35
    elif max_size and size >= max_size * 0.88:
        score += 18
    if bold:
        score += 18
    if ":" in text:
        score += 8
    if not text.endswith("."):
        score += 6
    upper_ratio = sum(1 for ch in text if ch.isupper()) / max(1, sum(1 for ch in text if ch.isalpha()))
    if 0.05 <= upper_ratio <= 0.50:
        score += 6
    score -= index
    return score, -index


def is_title_style(line: PreviewLine, max_size: float) -> bool:
    if not is_probable_title(line.text):
        return False
    if line.bold:
        return True
    return bool(max_size and line.size >= max_size * 0.88)


def merged_styled_title_candidates(preview_lines: list[PreviewLine], max_size: float) -> list[tuple[tuple[int, int], str]]:
    candidates: list[tuple[tuple[int, int], str]] = []
    i = 0
    while i < min(len(preview_lines), 28):
        line = preview_lines[i]
        if not is_title_style(line, max_size):
            i += 1
            continue

        group = [line]
        j = i + 1
        while j < min(len(preview_lines), 28):
            current = preview_lines[j]
            previous = group[-1]
            close_size = abs(current.size - previous.size) <= max(1.2, max_size * 0.08)
            close_vertical = current.top - previous.top <= max(42, previous.size * 2.6)
            same_style = (current.bold == previous.bold) or current.bold or previous.bold
            if is_title_style(current, max_size) and close_size and close_vertical and same_style:
                group.append(current)
                j += 1
                continue
            break

        if len(group) >= 2:
            merged = clean_line(" ".join(part.text for part in group))
            words = merged.split()
            if len(words) > 20:
                merged = " ".join(words[:20])
            if is_probable_title(merged):
                score = title_score(group[0], i, True, max_size)[0] + 45 + (len(group) * 5)
                candidates.append(((score, -i), merged))
        i += 1
    return candidates


def suggest_titles(first_page_text: str, metadata_title: str, preview_lines: list[PreviewLine]) -> list[str]:
    candidates: list[tuple[tuple[int, int], str]] = []
    if is_probable_title(metadata_title):
        candidates.append(((105, 0), metadata_title))

    max_size = max((line.size for line in preview_lines), default=0)
    candidates.extend(merged_styled_title_candidates(preview_lines, max_size))
    abstract_index = next(
        (i for i, line in enumerate(preview_lines) if line.text.casefold().startswith("abstract")),
        len(preview_lines),
    )
    for index, line in enumerate(preview_lines[:40]):
        if is_probable_title(line.text):
            candidates.append((title_score(line, index, index < abstract_index, max_size), line.text))
        if index + 1 < len(preview_lines):
            combined = clean_line(f"{line.text} {preview_lines[index + 1].text}")
            words = combined.split()
            if len(words) > 20:
                combined = " ".join(words[:20])
            if is_probable_title(combined):
                candidates.append((title_score(combined, index, index < abstract_index, max_size), combined))

    raw_lines = [clean_line(line) for line in first_page_text.splitlines()]
    text_lines = [line for line in raw_lines if line][:45]
    text_abstract_index = next(
        (i for i, line in enumerate(text_lines) if line.casefold().startswith("abstract")),
        len(text_lines),
    )
    for index, line in enumerate(text_lines):
        if is_probable_title(line):
            candidates.append((title_score(line, index, index < text_abstract_index, 0), line))

    candidates.sort(reverse=True)
    return unique_keep_order([line for _, line in candidates])[:10]


def suggest_for_pdf(path: Path, total_count: int, loaded_count: int) -> PdfSuggestion:
    is_encrypted, needs_password, encryption_status = inspect_pdf_security(path)
    first_page_text, metadata_title, metadata_years, pypdf_error = text_from_pypdf(path)
    preview_lines, layout_error = extract_layout_lines(path)
    first_page_image = render_first_page_image(path)
    preview_text = normalize_space(first_page_text[:1400] or " ".join(line.text for line in preview_lines[:30]))
    titles = suggest_titles(first_page_text, metadata_title, preview_lines)
    text_years = unique_keep_order(YEAR_RE.findall(first_page_text + " " + " ".join(line.text for line in preview_lines)))
    years = unique_keep_order(text_years + metadata_years)
    error = pypdf_error or layout_error
    return PdfSuggestion(
        path=str(path),
        currentName=path.name,
        isEncrypted=is_encrypted,
        needsPassword=needs_password,
        encryptionStatus=encryption_status,
        titleCandidates=titles,
        yearCandidates=years,
        metadataTitle=metadata_title,
        metadataYears=metadata_years,
        firstPagePreview=preview_text,
        firstPageImage=first_page_image,
        previewLines=preview_lines,
        totalPdfCount=total_count,
        loadedPdfCount=loaded_count,
        error=error,
    )


def sanitize_filename_part(value: str) -> str:
    value = normalize_space(value)
    value = re.sub(r'[<>:"/\\|?*\x00-\x1f]', " ", value)
    value = re.sub(r"\s+", " ", value).strip(" .")
    return value[:160].strip(" .")


def unique_target_path(folder: Path, filename: str, original: Path) -> Path:
    target = folder / filename
    if str(target.resolve()).casefold() == str(original.resolve()).casefold():
        return target
    stem = target.stem
    suffix = target.suffix
    counter = 2
    while target.exists():
        target = folder / f"{stem} ({counter}){suffix}"
        counter += 1
    return target


def rename_pdf(path_text: str, year: str, title: str) -> dict[str, Any]:
    source = Path(path_text)
    if not source.exists() or source.suffix.casefold() != ".pdf":
        return {"ok": False, "path": path_text, "error": "PDF 文件不存在"}
    clean_year = sanitize_filename_part(year)
    clean_title = sanitize_filename_part(title)
    if not YEAR_IN_TEXT_RE.search(clean_year):
        return {"ok": False, "path": path_text, "error": "第一段需要包含 4 位年份，例如 2026、chapter2026、ppt2026"}
    if not clean_title:
        return {"ok": False, "path": path_text, "error": "标题不能为空"}
    done_folder = source.parent / "Done"
    done_folder.mkdir(exist_ok=True)
    target = unique_target_path(done_folder, f"{clean_year} {clean_title}.pdf", source)
    if target == source:
        return {"ok": True, "path": str(source), "newPath": str(target), "unchanged": True}
    source.rename(target)
    return {"ok": True, "path": str(source), "newPath": str(target)}


def skip_pdf(path_text: str) -> dict[str, Any]:
    source = Path(path_text)
    if not source.exists() or source.suffix.casefold() != ".pdf":
        return {"ok": False, "path": path_text, "error": "PDF 文件不存在"}
    skipped_folder = source.parent / "Skipped"
    skipped_folder.mkdir(exist_ok=True)
    target = unique_target_path(skipped_folder, source.name, source)
    source.rename(target)
    return {"ok": True, "path": str(source), "newPath": str(target)}


def delete_pdf_to_recycle_bin(path_text: str) -> dict[str, Any]:
    source = Path(path_text)
    if not source.exists() or source.suffix.casefold() != ".pdf":
        return {"ok": False, "path": path_text, "error": "PDF 文件不存在"}
    if os.name != "nt":
        return {"ok": False, "path": path_text, "error": "当前系统不支持移动到 Windows 垃圾箱"}

    class SHFILEOPSTRUCTW(ctypes.Structure):
        _fields_ = [
            ("hwnd", ctypes.c_void_p),
            ("wFunc", ctypes.c_uint),
            ("pFrom", ctypes.c_wchar_p),
            ("pTo", ctypes.c_wchar_p),
            ("fFlags", ctypes.c_ushort),
            ("fAnyOperationsAborted", ctypes.c_bool),
            ("hNameMappings", ctypes.c_void_p),
            ("lpszProgressTitle", ctypes.c_wchar_p),
        ]

    FO_DELETE = 3
    FOF_ALLOWUNDO = 0x0040
    FOF_NOCONFIRMATION = 0x0010
    FOF_NOERRORUI = 0x0400
    FOF_SILENT = 0x0004

    operation = SHFILEOPSTRUCTW()
    operation.wFunc = FO_DELETE
    operation.pFrom = str(source.resolve()) + "\0\0"
    operation.fFlags = FOF_ALLOWUNDO | FOF_NOCONFIRMATION | FOF_NOERRORUI | FOF_SILENT
    result = ctypes.windll.shell32.SHFileOperationW(ctypes.byref(operation))
    if result != 0 or operation.fAnyOperationsAborted:
        return {"ok": False, "path": path_text, "error": f"移动到垃圾箱失败：{result}"}
    return {"ok": True, "path": str(source), "deleted": True}


def list_encrypted_pdfs(folder: Path) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    for path in sorted(folder.glob("*.pdf"), key=lambda p: p.name.casefold()):
        is_encrypted, needs_password, status = inspect_pdf_security(path)
        if is_encrypted:
            results.append(
                {
                    "path": str(path),
                    "name": path.name,
                    "needsPassword": needs_password,
                    "status": status,
                }
            )
    return results


HTML = r"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>PDF 标题改名工具</title>
  <style>
    :root { color-scheme: light; font-family: "Segoe UI", "Microsoft YaHei", Arial, sans-serif; }
    body { margin: 0; background: #f6f7f9; color: #18202a; }
    main { max-width: 1280px; margin: 0 auto; padding: 28px 20px 56px; }
    h1 { margin: 0 0 8px; font-size: 28px; }
    .lead { margin: 0 0 22px; color: #526071; }
    .panel, .item { background: #fff; border: 1px solid #dce2ea; border-radius: 8px; }
    .panel { padding: 18px; }
    .row { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
    input[type="text"] { flex: 1 1 320px; padding: 11px 12px; border: 1px solid #cbd5df; border-radius: 6px; font-size: 15px; min-width: 0; }
    button { border: 0; border-radius: 6px; padding: 10px 14px; background: #1f6feb; color: #fff; font-size: 15px; cursor: pointer; }
    button.secondary { background: #4b5563; }
    button.ghost { background: #eef2f7; color: #253143; border: 1px solid #d4dce8; }
    button.danger { background: #b42318; }
    button:disabled { opacity: .55; cursor: default; }
    .hint { margin-top: 10px; color: #637083; font-size: 13px; }
    .status { margin: 18px 0; color: #344054; }
    .item { margin-top: 14px; padding: 16px; }
    .item.done { opacity: .72; }
    .item.encrypted { border-color: #f59e0b; background: #fff8eb; }
    .topline { display: flex; justify-content: space-between; gap: 12px; align-items: flex-start; }
    .item h2 { margin: 0 0 12px; font-size: 17px; overflow-wrap: anywhere; }
    .layout { display: grid; grid-template-columns: minmax(0, 1fr) 504px; gap: 16px; align-items: start; }
    .field { margin-bottom: 12px; }
    .field strong { display: block; margin-bottom: 6px; }
    .chips { display: flex; gap: 8px; flex-wrap: wrap; }
    .chip { background: #f1f5f9; color: #172033; border: 1px solid #d7dee8; border-radius: 999px; padding: 7px 10px; max-width: 100%; overflow-wrap: anywhere; }
    .chip.title-candidate { text-align: left; }
    .prefixChoices { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 10px; }
    .prefixChoice { display: inline-flex; align-items: center; gap: 5px; background: #f8fafc; border: 1px solid #d7dee8; border-radius: 999px; padding: 7px 10px; cursor: pointer; }
    .target { display: grid; grid-template-columns: 120px minmax(0, 1fr); gap: 8px; margin: 12px 0; }
    .filename { color: #475467; font-size: 13px; overflow-wrap: anywhere; }
    .previewBox { border: 1px solid #d4dce8; border-radius: 8px; background: #fbfcfe; height: 360px; overflow-y: auto; padding: 16px; }
    .previewLine { margin: 0 0 8px; line-height: 1.2; color: #1f2937; }
    .previewLine.bold { font-weight: 700; }
    .imagePreviewBlock { margin-top: 16px; }
    .imagePreviewBox { border: 1px solid #d4dce8; border-radius: 8px; background: #eef2f7; height: 420px; overflow: auto; padding: 10px; }
    .imagePreviewBox img { display: block; width: 100%; min-width: 420px; max-width: none; height: auto; background: #fff; box-shadow: 0 1px 4px rgba(15, 23, 42, .18); }
    .imagePreviewHint { margin: 5px 0 8px; color: #667085; font-size: 12px; }
    .fallbackPreview { color: #667085; font-size: 13px; line-height: 1.45; }
    .actions { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 12px; }
    .error { color: #b42318; }
    .ok { color: #047857; }
    .warning { color: #92400e; font-weight: 700; }
    .badge { display: inline-flex; align-items: center; border-radius: 999px; padding: 4px 9px; background: #fef3c7; color: #92400e; font-size: 12px; font-weight: 700; }
    .encrypted-list { margin-top: 12px; padding: 12px; border: 1px solid #f0c36d; border-radius: 8px; background: #fff8eb; }
    .encrypted-list ul { margin: 8px 0 0; padding-left: 20px; }
    @media (max-width: 920px) { .layout { grid-template-columns: 1fr; } .previewBox { height: 280px; } .imagePreviewBox { height: 360px; } }
    @media (max-width: 640px) { .target { grid-template-columns: 1fr; } }
  </style>
</head>
<body>
<main>
  <h1>PDF 标题改名工具</h1>
  <p class="lead">读取 PDF 首页文字、字号/粗体信息和属性年份；你逐个确认后，改成「2026 Title.pdf」格式。</p>
  <section class="panel">
    <div class="row">
      <input id="folder" type="text" placeholder="输入 PDF 所在文件夹路径，例如 C:\Users\你的名字\Downloads\papers" />
      <button id="scan">读取 PDF</button>
      <button class="secondary" id="scanEncrypted">列出加密 PDF</button>
      <button class="secondary" id="scanProtectedAll">递归扫描受保护文件并生成 TXT</button>
    </div>
    <div class="hint">一次最多读取前 10 个 PDF。执行改名会移到 Done；放弃修改会移到 Skipped；可递归扫描 PDF/CSV/Word/Excel/PPT 的密码或 MIP 保护。</div>
  </section>
  <div id="status" class="status"></div>
  <section id="encryptedList"></section>
  <section id="list"></section>
</main>
<script>
const $ = (id) => document.getElementById(id);
let pdfs = [];

function escapeHtml(text) {
  return String(text || "").replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
}

function unique(values) {
  return [...new Set((values || []).filter(Boolean))];
}

function appendToInput(input, text) {
  const current = input.value.trim();
  input.value = current ? `${current} ${text}` : text;
  input.dispatchEvent(new Event("input"));
}

function setInput(input, text) {
  input.value = text;
  input.dispatchEvent(new Event("input"));
}

function previewLines(pdf) {
  if (pdf.previewLines && pdf.previewLines.length) {
    const maxSize = Math.max(...pdf.previewLines.map(line => Number(line.size) || 10), 10);
    return pdf.previewLines.map(line => {
      const size = Math.max(12, Math.min(28, 13 + ((Number(line.size) || 10) / maxSize) * 10));
      const cls = line.bold ? "previewLine bold" : "previewLine";
      return `<p class="${cls}" style="font-size:${size.toFixed(1)}px">${escapeHtml(line.text)}</p>`;
    }).join("");
  }
  return `<div class="fallbackPreview">${escapeHtml(pdf.firstPagePreview || "没有可预览的首页文字。扫描版 PDF 可能需要先 OCR。")}</div>`;
}

function pageImagePreview(pdf) {
  if (!pdf.firstPageImage) {
    return `<div class="fallbackPreview">无法生成首页图片预览。仍可使用右侧文字预览。</div>`;
  }
  return `<img src="${pdf.firstPageImage}" alt="PDF 首页图片预览">`;
}

const PREFIX_OPTIONS = ["", "Work", "Report", "Ad", "Abstr", "Book", "Chapter", "Parts", "List", "Dissertation", "Thesis"];

function prefixChoices(index) {
  return PREFIX_OPTIONS.map((prefix, optionIndex) => {
    const label = prefix || "无前缀";
    return `<label class="prefixChoice">
      <input type="radio" name="prefix-${index}" data-role="prefix" value="${escapeHtml(prefix)}" ${optionIndex === 0 ? "checked" : ""}>
      <span>${escapeHtml(label)}</span>
    </label>`;
  }).join("");
}

function renderList() {
  $("list").innerHTML = pdfs.map((pdf, index) => {
    const years = unique(pdf.yearCandidates);
    const titles = unique(pdf.titleCandidates);
    const defaultYear = years[0] || "";
    const defaultTitle = "";
    const titleChips = titles.map(title => `<button type="button" class="chip title-candidate" data-action="append-title" data-index="${index}" data-value="${escapeHtml(title)}">${escapeHtml(title)}</button>`).join("");
    const yearChips = years.map(year => `<button type="button" class="chip" data-action="set-year" data-index="${index}" data-value="${escapeHtml(year)}">${escapeHtml(year)}</button>`).join("");
    const encryptedBadge = pdf.isEncrypted ? `<span class="badge">${escapeHtml(pdf.encryptionStatus || "已加密")}</span>` : "";
    return `<article class="item ${pdf.isEncrypted ? "encrypted" : ""}" data-index="${index}">
      <div class="topline">
        <h2>${escapeHtml(pdf.currentName)} ${encryptedBadge}</h2>
        <span class="filename" data-role="result"></span>
      </div>
      ${pdf.needsPassword ? `<p class="warning">这个 PDF 需要密码或受保护，可能无法自动读取标题。可以放弃修改移到 Skipped，或手动输入后尝试改名。</p>` : ""}
      ${pdf.error ? `<p class="error">${escapeHtml(pdf.error)}</p>` : ""}
      <div class="layout">
        <div>
          <div class="field">
            <strong>年份候选</strong>
            <div class="chips">${yearChips || '<span class="error">没有自动年份，请手动输入</span>'}</div>
          </div>
          <div class="field">
            <strong>标题候选（点击后追加到标题输入框）</strong>
            <div class="chips">${titleChips || '<span class="error">没有自动标题，请手动输入</span>'}</div>
          </div>
          <div class="target">
            <strong>前缀</strong>
            <div class="prefixChoices">${prefixChoices(index)}</div>
            <strong>年份</strong>
            <input type="text" data-role="year" value="${escapeHtml(defaultYear)}" placeholder="例如 2026">
            <strong>标题</strong>
            <input type="text" data-role="title" value="${escapeHtml(defaultTitle)}" placeholder="点击候选追加，或手动输入标题">
          </div>
          <div class="filename" data-role="filename"></div>
          <div class="actions">
            <button data-action="rename-one" data-index="${index}">执行改名</button>
            <button class="ghost" data-action="skip-one" data-index="${index}">放弃修改</button>
            <button class="danger" data-action="delete-one" data-index="${index}">删除到垃圾箱</button>
          </div>
        </div>
        <div>
          <strong>首页上半页预览</strong>
          <div class="previewBox">${previewLines(pdf)}</div>
          <div class="imagePreviewBlock">
            <strong>PDF 首页图片预览</strong>
            <div class="imagePreviewHint">使用预览框滚动条调节查看位置。</div>
            <div class="imagePreviewBox">${pageImagePreview(pdf)}</div>
          </div>
        </div>
      </div>
    </article>`;
  }).join("");
  document.querySelectorAll(".item").forEach(updateFilename);
}

function updateFilename(item) {
  const year = item.querySelector('[data-role="year"]').value.trim();
  const prefix = item.querySelector('[data-role="prefix"]:checked')?.value || "";
  const title = item.querySelector('[data-role="title"]').value.trim();
  const output = item.querySelector('[data-role="filename"]');
  const firstPart = `${prefix}${year}`;
  output.textContent = year && title ? `目标位置：Done/${firstPart} ${title}.pdf` : "目标位置：请填写年份和标题";
}

async function postJson(url, data) {
  const res = await fetch(url, { method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(data) });
  const json = await res.json();
  if (!res.ok) throw new Error(json.error || "操作失败");
  return json;
}

async function scan() {
  $("status").textContent = "正在读取 PDF 首页、字号和属性...";
  $("scan").disabled = true;
  try {
    const data = await postJson("/api/scan", { folder: $("folder").value });
    pdfs = data.items;
    const limitText = data.total > data.loaded ? `只显示前 ${data.loaded} 个。` : "";
    $("status").innerHTML = `找到 ${data.total} 个 PDF，已读取 ${data.loaded} 个。${limitText}`;
    renderList();
  } catch (err) {
    $("status").innerHTML = `<span class="error">${escapeHtml(err.message)}</span>`;
  } finally {
    $("scan").disabled = false;
  }
}

async function scanEncrypted() {
  $("status").textContent = "正在检测加密 PDF...";
  $("scanEncrypted").disabled = true;
  try {
    const data = await postJson("/api/encrypted-list", { folder: $("folder").value });
    if (!data.items.length) {
      $("encryptedList").innerHTML = `<div class="encrypted-list"><span class="ok">没有检测到加密 PDF。</span></div>`;
    } else {
      const rows = data.items.map(item => `<li><strong>${escapeHtml(item.name)}</strong> - ${escapeHtml(item.status || "已加密")}</li>`).join("");
      $("encryptedList").innerHTML = `<div class="encrypted-list"><strong>加密 PDF 列表（${data.items.length} 个）</strong><ul>${rows}</ul></div>`;
    }
    $("status").textContent = `检测完成：共 ${data.total} 个 PDF。`;
  } catch (err) {
    $("status").innerHTML = `<span class="error">${escapeHtml(err.message)}</span>`;
  } finally {
    $("scanEncrypted").disabled = false;
  }
}

async function scanProtectedAll() {
  $("status").textContent = "正在递归扫描 PDF、CSV、Word、Excel、PPT...";
  $("scanProtectedAll").disabled = true;
  try {
    const data = await postJson("/api/protected-report", { folder: $("folder").value });
    const rows = data.items.map(item => `<li><strong>${escapeHtml(item.name)}</strong> [${escapeHtml(item.type)}] - ${escapeHtml(item.status)}<br><span class="filename">${escapeHtml(item.path)}</span></li>`).join("");
    $("encryptedList").innerHTML = `<div class="encrypted-list">
      <strong>受保护文件列表（${data.items.length} 个）</strong>
      <div class="filename">TXT 已生成：${escapeHtml(data.reportPath)}</div>
      ${data.items.length ? `<ul>${rows}</ul>` : '<p class="ok">没有检测到带密码或 Microsoft Information Protection 的文件。</p>'}
    </div>`;
    $("status").textContent = `扫描完成：检查 ${data.scanned} 个支持的文件，发现 ${data.items.length} 个受保护文件。`;
  } catch (err) {
    $("status").innerHTML = `<span class="error">${escapeHtml(err.message)}</span>`;
  } finally {
    $("scanProtectedAll").disabled = false;
  }
}

async function renameOne(index, item) {
  const pdf = pdfs[index];
  const year = item.querySelector('[data-role="year"]').value.trim();
  const prefix = item.querySelector('[data-role="prefix"]:checked')?.value || "";
  const yearPart = `${prefix}${year}`;
  const title = item.querySelector('[data-role="title"]').value.trim();
  const button = item.querySelector('[data-action="rename-one"]');
  button.disabled = true;
  try {
    const data = await postJson("/api/rename-one", { path: pdf.path, year: yearPart, title });
    if (data.result.ok) {
      item.classList.add("done");
      item.querySelector('[data-role="result"]').innerHTML = `<span class="ok">已移到 Done：${escapeHtml(data.result.newPath.split(/[\\\\/]/).pop())}</span>`;
    } else {
      item.querySelector('[data-role="result"]').innerHTML = `<span class="error">${escapeHtml(data.result.error)}</span>`;
      button.disabled = false;
    }
  } catch (err) {
    item.querySelector('[data-role="result"]').innerHTML = `<span class="error">${escapeHtml(err.message)}</span>`;
    button.disabled = false;
  }
}

async function skipOne(index, item) {
  const pdf = pdfs[index];
  const button = item.querySelector('[data-action="skip-one"]');
  button.disabled = true;
  try {
    const data = await postJson("/api/skip-one", { path: pdf.path });
    if (data.result.ok) {
      item.classList.add("done");
      item.querySelector('[data-role="result"]').innerHTML = `<span class="ok">已移到 Skipped：${escapeHtml(data.result.newPath.split(/[\\\\/]/).pop())}</span>`;
      setTimeout(() => item.remove(), 500);
    } else {
      item.querySelector('[data-role="result"]').innerHTML = `<span class="error">${escapeHtml(data.result.error)}</span>`;
      button.disabled = false;
    }
  } catch (err) {
    item.querySelector('[data-role="result"]').innerHTML = `<span class="error">${escapeHtml(err.message)}</span>`;
    button.disabled = false;
  }
}

async function deleteOne(index, item) {
  const pdf = pdfs[index];
  if (!confirm(`删除到垃圾箱？\n${pdf.currentName}`)) return;
  const button = item.querySelector('[data-action="delete-one"]');
  button.disabled = true;
  try {
    const data = await postJson("/api/delete-one", { path: pdf.path });
    if (data.result.ok) {
      item.classList.add("done");
      item.querySelector('[data-role="result"]').innerHTML = `<span class="ok">已删除到垃圾箱：${escapeHtml(pdf.currentName)}</span>`;
      setTimeout(() => item.remove(), 500);
    } else {
      item.querySelector('[data-role="result"]').innerHTML = `<span class="error">${escapeHtml(data.result.error)}</span>`;
      button.disabled = false;
    }
  } catch (err) {
    item.querySelector('[data-role="result"]').innerHTML = `<span class="error">${escapeHtml(err.message)}</span>`;
    button.disabled = false;
  }
}

$("scan").addEventListener("click", scan);
$("scanEncrypted").addEventListener("click", scanEncrypted);
$("scanProtectedAll").addEventListener("click", scanProtectedAll);
$("folder").addEventListener("keydown", (event) => { if (event.key === "Enter") scan(); });
$("list").addEventListener("input", (event) => {
  const item = event.target.closest(".item");
  if (item) updateFilename(item);
});
$("list").addEventListener("click", (event) => {
  const control = event.target.closest("[data-action]");
  if (!control) return;
  const item = control.closest(".item");
  const index = Number(control.dataset.index);
  if (control.dataset.action === "append-title") {
    appendToInput(item.querySelector('[data-role="title"]'), control.dataset.value);
  }
  if (control.dataset.action === "set-year") {
    setInput(item.querySelector('[data-role="year"]'), control.dataset.value);
  }
  if (control.dataset.action === "rename-one") {
    renameOne(index, item);
  }
  if (control.dataset.action === "skip-one") {
    skipOne(index, item);
  }
  if (control.dataset.action === "delete-one") {
    deleteOne(index, item);
  }
});
</script>
</body>
</html>
"""


class Handler(BaseHTTPRequestHandler):
    def send_json(self, data: Any, status: int = 200) -> None:
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def read_json(self) -> dict[str, Any]:
        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length).decode("utf-8")
        return json.loads(body or "{}")

    def do_GET(self) -> None:
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path in {"/", "/index.html"}:
            body = HTML.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        self.send_error(404)

    def do_POST(self) -> None:
        try:
            data = self.read_json()
            if self.path == "/api/scan":
                folder_text = normalize_space(data.get("folder", ""))
                folder = Path(folder_text).expanduser()
                if not folder.exists() or not folder.is_dir():
                    self.send_json({"error": "文件夹不存在，请检查路径"}, 400)
                    return
                pdf_paths = sorted(folder.glob("*.pdf"), key=lambda p: p.name.casefold())
                selected_paths = pdf_paths[:MAX_PDFS_PER_SCAN]
                items = [
                    asdict(suggest_for_pdf(path, len(pdf_paths), len(selected_paths)))
                    for path in selected_paths
                ]
                self.send_json({"items": items, "total": len(pdf_paths), "loaded": len(selected_paths)})
                return
            if self.path == "/api/rename-one":
                result = rename_pdf(data.get("path", ""), data.get("year", ""), data.get("title", ""))
                self.send_json({"result": result})
                return
            if self.path == "/api/skip-one":
                result = skip_pdf(data.get("path", ""))
                self.send_json({"result": result})
                return
            if self.path == "/api/delete-one":
                result = delete_pdf_to_recycle_bin(data.get("path", ""))
                self.send_json({"result": result})
                return
            if self.path == "/api/encrypted-list":
                folder_text = normalize_space(data.get("folder", ""))
                folder = Path(folder_text).expanduser()
                if not folder.exists() or not folder.is_dir():
                    self.send_json({"error": "文件夹不存在，请检查路径"}, 400)
                    return
                pdf_paths = list(folder.glob("*.pdf"))
                self.send_json({"items": list_encrypted_pdfs(folder), "total": len(pdf_paths)})
                return
            if self.path == "/api/protected-report":
                folder_text = normalize_space(data.get("folder", ""))
                folder = Path(folder_text).expanduser()
                if not folder.exists() or not folder.is_dir():
                    self.send_json({"error": "文件夹不存在，请检查路径"}, 400)
                    return
                items, scanned = scan_protected_files_recursive(folder)
                report_path = write_protected_report(folder, items, scanned)
                self.send_json(
                    {
                        "items": items,
                        "scanned": scanned,
                        "reportPath": str(report_path),
                    }
                )
                return
            self.send_error(404)
        except Exception as exc:
            self.send_json({"error": str(exc)}, 500)

    def log_message(self, format: str, *args: Any) -> None:
        return


def main() -> None:
    url = f"http://127.0.0.1:{PORT}"
    print(f"PDF Title Renamer started: {url}")
    print("Close this window to stop the tool.")
    try:
        webbrowser.open(url)
    except Exception:
        pass
    server = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    server.serve_forever()


if __name__ == "__main__":
    main()
