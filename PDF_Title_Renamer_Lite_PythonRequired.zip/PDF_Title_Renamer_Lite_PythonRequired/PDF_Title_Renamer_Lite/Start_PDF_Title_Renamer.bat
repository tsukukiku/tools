@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  set "PY=py -3"
) else (
  set "PY=python"
)
%PY% -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)" >nul 2>nul
if errorlevel 1 (
  echo Python 3.10 or newer is required. Python 3.12 is recommended.
  echo Please install Python from https://www.python.org/downloads/windows/
  pause
  exit /b 1
)
%PY% -c "import pypdf, pdfplumber, pypdfium2, PIL" >nul 2>nul
if errorlevel 1 (
  echo Installing required Python packages...
  %PY% -m pip install -r requirements.txt
  if errorlevel 1 (
    echo Failed to install dependencies. Please check internet connection and Python/pip.
    pause
    exit /b 1
  )
)
%PY% app.py
pause
