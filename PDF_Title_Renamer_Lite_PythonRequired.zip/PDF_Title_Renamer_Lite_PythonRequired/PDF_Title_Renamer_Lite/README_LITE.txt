PDF Title Renamer Lite

这是轻量版，不包含 Python 本体，也不包含预装依赖。

要求：
- Windows 10/11
- Python 3.10 或更新版本
- 推荐 Python 3.12
- 第一次运行需要联网安装 Python 包

使用方法：
1. 安装 Python： https://www.python.org/downloads/windows/
   安装时建议勾选 “Add python.exe to PATH”。
2. 解压本 zip。
3. 双击 Start_PDF_Title_Renamer.bat。
4. 第一次启动会自动安装依赖。
5. 浏览器会打开 http://127.0.0.1:8765。
6. 关闭黑色窗口即可停止工具。

依赖包：
- pypdf
- pdfplumber
- pypdfium2
- Pillow

说明：
- 所有 PDF 都在本机处理，不上传云端。
- 首页图片预览由 pypdfium2 本地生成，不需要随包携带 Poppler。
- Done / Skipped 会在原 PDF 文件夹中自动创建。
- 删除到垃圾箱会进入 Windows 回收站，不是永久删除。
