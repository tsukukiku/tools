# PDF Title Renamer

本地网页工具，用来逐个确认 PDF 标题后改名为：

```text
2026 Title.pdf
```

## 功能

- 一次最多读取前 10 个 PDF。
- 标题候选参考首页文字的位置、字号和粗体。
- 点击标题候选，会追加到标题输入框现有文字后面。
- 文件名前缀可用圆点选择：无前缀、Work、Report、Ad、Abstr、Book、Chapter、Parts、List、Dissertation、Thesis。
- 无前缀时生成 `2026 Title.pdf`；选择前缀时生成 `Work2026 Title.pdf` 这类文件名。
- 每个 PDF 单独点击“执行改名”。
- 不想修改的 PDF 可以点“放弃修改”。
- 也可以点“删除到垃圾箱”，文件会进入 Windows 回收站，不是永久删除。
- 右侧显示首页上半页文字预览，带纵向滚动条。
- 左下方显示 PDF 首页图片预览，预览框带横向和纵向滚动条，可以拖动查看页面位置。
- 预览窗口已加宽，便于看首页文字。
- 加密 PDF 会用黄色标注。
- 点击“列出加密 PDF”可以生成当前文件夹里的加密 PDF 列表。
- 点击“递归扫描受保护文件并生成 TXT”会扫描当前文件夹和子文件夹内的 PDF、CSV、Word、Excel、PPT，列出密码保护或 Microsoft Information Protection 文件，并生成 `protected_files_report_YYYYMMDD_HHMMSS.txt`。
- 如果系统 Python 缺少 `pypdf`，程序会优先加载 Codex 自带依赖；仍然缺少时，会尝试只用 `pdfplumber` 读取首页文字。

## 使用方法

1. 关闭旧的工具启动窗口。
2. 双击 `start_windows.bat`。
3. 浏览器打开 `http://127.0.0.1:8765`。
4. 输入 PDF 所在文件夹路径。
5. 点击“读取 PDF”。
6. 为每个 PDF 确认年份和标题。
7. 点击该 PDF 卡片里的“执行改名”。

## 如果仍然显示“缺少 pypdf”

通常是旧版本服务还在运行。请关闭之前打开的黑色启动窗口，然后重新双击 `start_windows.bat`。

扫描版 PDF 如果没有可复制文字，需要先 OCR。
